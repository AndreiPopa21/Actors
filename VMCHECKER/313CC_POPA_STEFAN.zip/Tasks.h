#ifndef _TASKS_H_
#define _TASKS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Utils.h"

void TaskOne(char* input, char* output);
void TaskTwo(char* input, char* output);
void TaskThree(char* input, char* output);
void Bonus(char* input,char* output);

#endif