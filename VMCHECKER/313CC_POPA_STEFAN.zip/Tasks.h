#ifndef _TASKS_H_
#define _TASKS_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Utils.h"

void TaskOne(char* input, char* output);
void TaskTwo();
void TaskThree();
void Bonus();

#endif