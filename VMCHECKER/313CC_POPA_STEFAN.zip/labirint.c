#include <stdio.h>
#include <stdlib.h>

/*fisier sursa pentru rezolvarea celei de a doua probleme*/
int main(int argc, char* argv[]){
    return 0;
}